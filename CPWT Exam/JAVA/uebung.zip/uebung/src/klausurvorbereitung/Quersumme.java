package klausurvorbereitung;

public class Quersumme {

}
