package cs21_1_5_exception;


	public class PlatzMangelException extends Exception {
		
		public PlatzMangelException(String string) {
		
		}

		
	
	}

