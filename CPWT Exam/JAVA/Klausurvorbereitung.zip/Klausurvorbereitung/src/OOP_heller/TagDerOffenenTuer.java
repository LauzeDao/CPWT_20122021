package OOP_heller;

public class TagDerOffenenTuer {
	
	public static void main(String[] args) {
		
		String person [] = new String[5];
		int anzahl;
	}

}
