package OOP_heller;

public class Dozent {

}
