package OOP_heller;

public class Besucher {

}
