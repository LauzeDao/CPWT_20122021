package YTTUTs;

public class ifelse {	

	public static void main(String[] args) {
		
		int age = 21;
		
		if(age > 17) {
			System.out.println("Du darfst Alkohol kaufen");
		}
		else {
			System.out.println("verpiss dich alde");
		}
	}
}
